-remember to make database name as College, or change it from College to yours name in the code

-also remember to change data source to your's server name

-to upload database file, right click on Databases folder under name of your server in MSSMS, choose Import Data-tier Application
	and select College.bacpac file